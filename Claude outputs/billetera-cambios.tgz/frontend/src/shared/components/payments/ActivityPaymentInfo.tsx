import { useState } from 'react';
import { Banknote, Loader2 } from 'lucide-react';
import { paymentsService } from '../../../services/payments.service';
import type { ObligationType, PaymentSummary } from '../../../types/payments.types';
import { ConfirmModal } from '../common/ConfirmModal';
import PaymentStatusBadge from './PaymentStatusBadge';
import { formatCents, methodLabel } from './payment.utils';

interface Props {
  payment: PaymentSummary;
  obligationType: ObligationType;
  obligationId: string;
  vehiclePlate: string;
}

/**
 * Línea de pago dentro de las tarjetas de actividad (dueño/empleado).
 * Muestra importe, medio y estado según el backend. Si no hay pago, permite
 * registrar un cobro presencial para que no se le pida el pago al cliente.
 */
function ActivityPaymentInfo({ payment: initial, obligationType, obligationId, vehiclePlate }: Props) {
  const [payment, setPayment] = useState<PaymentSummary>(initial);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canRegister =
    (payment.status === 'NONE' || payment.status === 'REJECTED' || payment.status === 'CANCELLED') &&
    (payment.amountCents ?? payment.billedAmountCents ?? 0) > 0;

  const register = async () => {
    setConfirming(false);
    setBusy(true);
    setError(null);
    try {
      const p = await paymentsService.registerPresential(obligationType, obligationId);
      setPayment({
        status: p.status,
        method: p.method,
        amountCents: p.amountCents,
        billedAmountCents: p.billedAmountCents,
        coveredAmountCents: p.coveredAmountCents,
        paymentId: p.id,
        updatedAt: p.updatedAt,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-3 rounded-md border border-slate-100 bg-slate-50/60 p-2 text-xs">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <p className="text-slate-500">Pago</p>
          <p className="font-semibold text-slate-800">
            {payment.amountCents != null && payment.status !== 'COVERED' ? formatCents(payment.amountCents) : '—'}
            {payment.method && <span className="font-normal text-slate-500"> · {methodLabel[payment.method]}</span>}
          </p>
          {payment.coveredAmountCents > 0 && payment.status !== 'COVERED' && (
            <p className="text-[11px] text-violet-600">Reserva pagada: {formatCents(payment.coveredAmountCents)}</p>
          )}
        </div>
        <PaymentStatusBadge status={payment.status} />
      </div>

      {canRegister && (
        <button
          type="button"
          onClick={() => setConfirming(true)}
          disabled={busy}
          className="mt-2 inline-flex items-center gap-1 rounded-md border border-slate-300 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50"
        >
          {busy ? <Loader2 size={12} className="animate-spin" /> : <Banknote size={12} />} Registrar pago presencial
        </button>
      )}
      {error && <p className="mt-1 text-[11px] text-red-600">{error}</p>}

      <ConfirmModal
        isOpen={confirming}
        title="Registrar pago presencial"
        message={`¿Confirmás que el vehículo ${vehiclePlate} pagó ${formatCents(payment.amountCents)} en el estacionamiento? No se le pedirá el pago en la app.`}
        confirmText="Registrar"
        variant="info"
        onConfirm={register}
        onCancel={() => setConfirming(false)}
      />
    </div>
  );
}

export default ActivityPaymentInfo;
