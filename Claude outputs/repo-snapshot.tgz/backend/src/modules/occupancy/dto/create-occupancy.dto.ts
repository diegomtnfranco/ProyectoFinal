export class CreateOccupancyDto {}
