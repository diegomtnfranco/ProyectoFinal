import ForgotPassword from '../../features/auth/components/ForgotPassword';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from '../../features/auth/pages/LoginPage';
import RegisterPage from '../../features/auth/pages/RegisterPage';
import VerifyEmailPage from '../../features/auth/pages/VerifyEmailPage';
import ResetPasswordPage from '../../features/auth/pages/ResetPasswordPage';
import LandingPage from '../../features/landing/pages/LandingPage'
import ClientLayout from '../layouts/client-layout';
import ParkingListPage from '../../features/parking-lots/pages/ParkingListPage';
import ParkingDetailsPage from '../../features/parking-lots/pages/ParkingDetailsPage';
import OwnerLayout from '../layouts/owner-layout';
import EmployeeLayout from '../layouts/employee-layout';
import DashboardOwner from '../../features/owner/Dashboard';
import RatesPage from '../../features/owner/RatesPage';
import CreateCompanyForm from '../../features/auth/components/CreateCompanyForm';
import CompanyLocationForm from '../../features/auth/components/CompanyLocationForm';
import AdminLayout from '../layouts/admin-layout';
import CompaniesPage from '../../features/admin/pages/CompaniesPage';
import { ProtectedRoute } from '../../shared/components/common/ProtectedRoute';
import { UserRole } from '../../types/auth.types';
import MyReservationsPage from '../../features/parking-lots/pages/MyReservationsPage';
import ProfilePage from '../../features/profile/pages/ProfilePage';
import PendingCompaniesPages from '../../features/admin/pages/PendingCompaniesPages'
import EmployeesPage from '../../features/owner/EmployeesPage';
import QRManagementPage from '../../features/owner/QRManagementPage';
import ScanQRPage from '../../features/qr/pages/ScanQRPage';
import TotemCheckIn from '../../features/totem/pages/TotemCheckIn';
import TotemCheckOut from '../../features/totem/pages/TotemCheckOut';
import ParkingSettingsPage from '../../features/owner/ParkingSettingsPage';
import AboutUs from '../../features/landing/pages/AboutUs';
import AdminParkingDetailPage from '../../features/admin/pages/AdminParkingDetailPage';
import UsersPage from '../../features/admin/pages/UsersPage';
import AdminUserEditPage from '../../features/admin/pages/AdminUserEditPage';
import ParkingMapPage from '../../features/parking-lots/pages/ParkingMapPage';
import ActivityPage from '../../features/owner/ActivityPage';


// Actualizado al 18/06/2026
function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* RUTAS PÚBLICAS */}
        <Route path='/' element={<LandingPage />} />
        <Route path='/about-us' element={<AboutUs />} />
        <Route path='/login' element={<LoginPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="/verify-email" element={<VerifyEmailPage />} />
        <Route path="/create-company" element={<CreateCompanyForm />} />
        <Route path="/company-location" element={<CompanyLocationForm />} />
        <Route path="/scan/:type" element={<ScanQRPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* RUTAS DE TÓTEM */}
        <Route path="/public/qr/:parkingId/checkin" element={<TotemCheckIn />} />
        <Route path="/public/qr/:parkingId/checkout" element={<TotemCheckOut />} />

        {/* CLIENTE */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.CLIENT]} redirectTo="/" />}>
          <Route path="/client" element={<ClientLayout />}>
            <Route index element={<ParkingListPage />} />
            <Route path="parking-lots/:id" element={<ParkingDetailsPage />} />
            <Route path="my-reservations" element={<MyReservationsPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="map" element={<ParkingMapPage />} />
          </Route>
        </Route>

        {/* DUEÑO */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.PARKING_OWNER]} redirectTo="/" />}>
          <Route path="/owner" element={<OwnerLayout />}>
            <Route index element={<Navigate to="parking" replace />} />
            <Route path="parking" element={<DashboardOwner />} />
            <Route path="rates" element={<RatesPage />} />
            <Route path="employees" element={<EmployeesPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="qr" element={<QRManagementPage />} />
            <Route path="settings" element={<ParkingSettingsPage />} />
            <Route path="activity" element={<ActivityPage />} />
          </Route>
        </Route>

        {/* ADMIN */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.ADMIN]} redirectTo="/" />}>
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<Navigate to="companies" replace />} />
            <Route path="companies" element={<CompaniesPage />} />
            <Route path="companies/:id/edit" element={<AdminParkingDetailPage />} />
            <Route path="users" element={<UsersPage />} />
            <Route path="users/:id/edit" element={<AdminUserEditPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path='actives' element={<PendingCompaniesPages />} />
          </Route>
        </Route>

        {/* EMPLEADO */}
        <Route element={<ProtectedRoute allowedRoles={[UserRole.PARKING_EMPLOYEE]} redirectTo="/" />}>
          <Route path="/employee" element={<EmployeeLayout />}>
            <Route index element={<Navigate to="parking" replace />} />
            <Route path="parking" element={<DashboardOwner />} />
            <Route path="rates" element={<RatesPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="qr" element={<QRManagementPage />} />
            <Route path="activity" element={<ActivityPage />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRouter;