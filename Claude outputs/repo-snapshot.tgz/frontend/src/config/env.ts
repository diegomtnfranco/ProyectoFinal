export const env = {
  apiUrl: import.meta.env.VITE_API_URL ?? 'http://localhost:3000/api',
  socketUrl: import.meta.env.VITE_SOCKET_URL ?? 'http://localhost:3000/api',
  mapboxToken: import.meta.env.VITE_MAPBOX_TOKEN ?? ''
};
